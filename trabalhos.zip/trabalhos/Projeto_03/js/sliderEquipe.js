$(function(){

    function initSlider(){
        var amt = $('.sobre-autor').length
    }
})