



/*
var agenda = {
    name:'gabriel',
    sobrenome:'merigo',
    whatsapp:'(51) 8296-5035',
    nomeCompleto: function(){
        return this.name + ' ' + this.sobrenome
    }
}

console.dir(agenda.nomeCompleto())
*/

//**********Condicional**********//

var idade = 20

if(idade >= 18) {
    console.log('voce é maior de 18 anos.')
}

else{
    console.log('vc é menor de idade')
}